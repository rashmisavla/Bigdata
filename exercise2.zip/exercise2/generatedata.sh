#!/bin/bash
 for i in `seq 1 $1`; do
 echo $RANDOM $RANDOM $RANDOM $RANDOM
 done

